# Initialize i18n package
